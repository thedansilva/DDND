package com.mycompany.mcserver;

import java.io.*;
import java.net.*;
import java.util.*;

public class MulticastServerThread extends Thread {
    MulticastSocket socket = null;
    BufferedReader in = null;
    InetAddress group;
    int type;
    
    public MulticastServerThread(int type) throws IOException {
        super("MulticastServerThread");
        this.type = type;
        socket = new MulticastSocket(4445);
        group = InetAddress.getByName("230.0.0.1");
        socket.joinGroup(group);
    }
    
    public void run() {
        Map map = new Map();
        if(type == 1) {
            DatagramPacket packet, pkt;
            String[] players = new String[5];
            int playerCount = 0;
            try {
                byte[] empty;
                while(true) {
                    String[] str = new String[3];
                    empty = new byte[256];
                    packet = new DatagramPacket(empty, empty.length);
                    System.out.println("waiting");
                    socket.receive(packet);
                    String received = new String(packet.getData(), 0, packet.getLength());
                    str = received.split(";");
                    System.out.println("str[0] = "+str[0]+" / str[1] = "+str[1]);
                    System.out.println("Received: "+received);

                    //decide what to do with packet
                    //start with adding username to players array
                    if (str[0].equals("username")) {
                        if (playerCount >= 5) {
                            pkt = buildPacket("Sorry, the game is at the max number of players.");
                            socket.send(pkt);
                        } else {
                            players[playerCount] = str[1];
                            System.out.println("Player "+(playerCount+1)+": "+players[playerCount]+" joined.");
                            String yep = "";
                            for(int x = 0; x < 130; x++) {
                           yep += "-";
                            }
                                yep += "\n";
                            yep += "UN: " + players[playerCount] + "\n";
                            pkt = buildPacket(yep);
                            socket.send(pkt);
                            playerCount++;
                        }
                    } else if (str[0].equals("info")) {

                    } else if (str[0].equals("command")) {
                        System.out.println("Got command.");
                        switch(str[1]) {
                            case "up":
                                map.moveCharacter(0);
                                break;
                            case "left":
                                map.moveCharacter(1);
                                break;
                            case "down":
                                map.moveCharacter(2);
                                break;
                            case "right":
                                map.moveCharacter(3);
                                break;
                        }
                            map.generateMap();
                            pkt = buildPacket(map.returnMap());
                            socket.send(pkt);
                    } else if (str[0].equals("echo")) {
                        pkt = buildPacket("hello from server");
                        socket.send(pkt);
                    }

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (type == 2) {
            //Output output = new Output();
            try {
                Output output = new Output();
                //output.sendText();
            } /*catch(InterruptedException e) {

            }*/ catch(IOException e){};
            //try{output.sendText();}catch(InterruptedException e){};
        }
	   socket.close();
    }

    public DatagramPacket buildPacket(String input) {
        DatagramPacket pkt;
        byte[] buf = new byte[256];
        buf = input.getBytes();
        pkt = new DatagramPacket(buf, buf.length, group, 4446);
        return pkt;
    }
}

class Output {
    MulticastSocket socket;
    InetAddress group;

    Output() throws IOException {
        this.socket = new MulticastSocket(4447);
        this.group = InetAddress.getByName("230.0.0.1");
        socket.joinGroup(group);
    }

    void sendText() throws InterruptedException {
        try {
            while(true){
                byte[] empty = new byte[256];
                String txt = "This came from output class.";
                empty = txt.getBytes();
                DatagramPacket packet = new DatagramPacket(empty, empty.length, group, 4446);
                System.out.println("Sending txt");
                socket.send(packet);
                Thread.sleep(3000);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } 
    }
}